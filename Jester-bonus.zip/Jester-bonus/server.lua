ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

-- Command voor claimen
RegisterCommand('claim', function(source, args, rawCommand)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return end

    local identifier = xPlayer.identifier

    -- Controleer of de speler al heeft geclaimd
    exports.oxmysql:query('SELECT claimed FROM claims WHERE identifier = ?', {identifier}, function(result)
        if result[1] and result[1].claimed then
            TriggerClientEvent('chat:addMessage', source, {
                color = {255, 0, 0},
                multiline = true,
                args = {"Beloning", "Je hebt je beloning al opgehaald!"}
            })
            return
        end

        -- Open het menu voor de speler
        TriggerClientEvent('Jester-bonus:openMenu', source)
    end)
end, false)

-- Verwerk de keuze van de speler
RegisterNetEvent('Jester-bonus:chooseReward', function(choice)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return end

    local identifier = xPlayer.identifier

    -- Controleer of de speler al heeft geclaimd
    exports.oxmysql:query('SELECT claimed FROM claims WHERE identifier = ?', {identifier}, function(result)
        if result[1] and result[1].claimed then
            TriggerClientEvent('chat:addMessage', source, {
                color = {255, 0, 0},
                multiline = true,
                args = {"Beloning", "Je hebt je beloning al opgehaald!"}
            })
            return
        end

        -- Verwerk de keuze
        if choice == 'money' then
            -- Voeg 400k cash toe aan de speler
            xPlayer.addMoney(400000)  -- Gebruik addMoney voor cash
            TriggerClientEvent('chat:addMessage', source, {
                color = {0, 255, 0},
                multiline = true,
                args = {"Beloning", "Je hebt 400k ontvangen in cash!"}
            })

        elseif choice == 'weapon' then
            -- Geef de speler het wapen en de munitie
            xPlayer.addInventoryItem('weapon_m1911', 1)  -- M1911 wapen
            xPlayer.addInventoryItem('ammo-9', 200)     -- 200 munitie voor het wapen (gebruik ammo-9)
            TriggerClientEvent('chat:addMessage', source, {
                color = {0, 255, 0},
                multiline = true,
                args = {"Beloning", "Je hebt een M1911 en 200 munitie ontvangen!"}
            })
        end

        -- Zet in de database dat de beloning is geclaimd
        exports.oxmysql:execute('INSERT INTO claims (identifier, claimed) VALUES (?, ?) ON DUPLICATE KEY UPDATE claimed = 1', {identifier, 1})
    end)
end)

-- Maak de database bij resource start
AddEventHandler('onResourceStart', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end

    exports.oxmysql:execute([[
        CREATE TABLE IF NOT EXISTS claims (
            identifier VARCHAR(50) NOT NULL PRIMARY KEY,
            claimed BOOLEAN NOT NULL DEFAULT 0
        )
    ]])
end)
