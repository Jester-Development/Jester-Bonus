ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterNetEvent('Jester-bonus:openMenu', function()
    local elements = {
        {label = '400k Contant', value = 'money'},
        {label = 'M1911 + 200 Ammo', value = 'weapon'}
    }

    -- Open het menu met align = 'right' voor de rechterkant van het scherm
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'bonus_menu', {
        title    = 'Kies je beloning',
        align    = 'right',  -- Verplaatst het menu naar de rechterkant
        elements = elements
    }, function(data, menu)
        local choice = data.current.value

        -- Sluit het menu
        menu.close()

        -- Verzend de keuze naar de server
        TriggerServerEvent('Jester-bonus:chooseReward', choice)
    end, function(data, menu)
        menu.close()
    end)
end)
