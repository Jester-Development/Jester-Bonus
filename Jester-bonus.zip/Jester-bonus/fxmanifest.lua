fx_version 'cerulean'
game 'gta5'

author 'Jester🎭'
description 'Jester-bonus: ESX Claim System met ESX_Menu_Default en chatberichten'
version '1.0.0'

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}

client_scripts {
    'client.lua'
}

lua54 'yes'
